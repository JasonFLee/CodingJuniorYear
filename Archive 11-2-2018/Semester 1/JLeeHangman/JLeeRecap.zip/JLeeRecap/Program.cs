﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JLeeHangman
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(" 0");
            Console.WriteLine(" I");
            Console.WriteLine("-I-");
            Console.WriteLine(" I");
            Console.WriteLine(" ^");
           
            Random rand = new Random();
            int randoMnumber = rand.Next(0, 20);
            string[] week = new string[20];
            
            week[0] = "grotesque";
            week[1] = "number";
            week[2] = "self";
            week[3] = "lamp"; 
            week[4] = "show";
            week[5] = "grandfather";
            week[6] = "scarecrow";
            week[7] = "poopidyscoop";
            week[8] = "melodic";
            week[9] = "lie";
            week[10] = "meal";
            week[11] = "idiotic";
            week[12] = "eggnog";
            week[13] = "salty";
            week[14] = "cynical";
            week[15] = "amazing";
            week[16] = "premium";
            week[17] = "bradpitslongsocialsecuritycheck";
            week[18] = "grubby";
            week[19] = "wonderful";
            
            
            string chosenNum = week[randoMnumber];
            Console.WriteLine(chosenNum);
           








            Console.WriteLine("Enter guess");
            string s = Console.ReadLine();

            Console.WriteLine(chosenNum.Length);
        //    for (int i = 0; i < chosenNum.Length; i++)
         //   {
         //       
         //       if (s[i] == chosenNum[i])
           //     {
             //       Console.WriteLine(":DDDDDDDD");
           //        
           //     }
          //  }
                


           
            

            Console.ReadLine();
        }
    }
}
